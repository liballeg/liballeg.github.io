/* Allegro datafile object indexes, produced by grabber v2.2 + WIP */
/* Datafile: d:\webpages\ezine\articles\issue1\pong\code\pong.dat */
/* Date: Thu Oct 30 16:49:42 1997 */
/* Do not hand edit! */

#define pong_ball                        0        /* RLE  */
#define pong_bar                         1        /* RLE  */
#define pong_boing                       2        /* SAMP */
#define pong_pal                         3        /* PAL  */
#define pong_text                        4        /* FONT */
#define pong_COUNT                       5

