This minimal DirectX 8.0 SDK is largely based upon work from Paul Gerfen.

paul@gamecoding.co.uk
www.gamecoding.co.uk
