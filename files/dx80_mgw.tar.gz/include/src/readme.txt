Patch(es) against original Microsoft DirectX 8.0 SDK header files here.

Patch(es) should not include files not existant in this archive, in other words
do not use the -N parameter with diff.
