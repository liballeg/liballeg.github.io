/* Allegro data file object indexes, produced by grabber v2.1 + WIP */
/* Datafile: c:\allegro\setup\setup.dat */
/* Date: Sun Dec  1 19:25:08 1996 */
/* Do not hand edit! */

#define SETUP_PALLETE                    0        /* PAL  */
#define TEST_MIDI                        1        /* MIDI */
#define TEST_SAMPLE                      2        /* SAMP */

