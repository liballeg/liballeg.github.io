/* Allegro data file object indexes, produced by grabber v2.2 beta */
/* Datafile: d:\allegro\demo\demo.dat */
/* Date: Sat Feb  8 21:19:23 1997 */
/* Do not hand edit! */

#define BOOM_SPL                         0        /* SAMP */
#define BULLET                           1        /* RLE  */
#define DEATH_SPL                        2        /* SAMP */
#define END_FONT                         3        /* FONT */
#define END_TEXT                         4        /* DATA */
#define ENGINE_SPL                       5        /* SAMP */
#define EXPLODE1                         6        /* RLE  */
#define EXPLODE2                         7        /* RLE  */
#define EXPLODE3                         8        /* RLE  */
#define EXPLODE4                         9        /* RLE  */
#define EXPLODE5                         10       /* RLE  */
#define GAME_MUSIC                       11       /* MIDI */
#define GAME_PAL                         12       /* PAL  */
#define GO_BMP                           13       /* BMP  */
#define INTRO_ANIM                       14       /* FLIC */
#define INTRO_BMP_1                      15       /* BMP  */
#define INTRO_BMP_2                      16       /* BMP  */
#define INTRO_BMP_3                      17       /* BMP  */
#define INTRO_BMP_4                      18       /* BMP  */
#define INTRO_SPL                        19       /* SAMP */
#define SHIP_GO                          20       /* RLE  */
#define SHIP_STILL                       21       /* RLE  */
#define SHOOT_SPL                        22       /* SAMP */
#define TITLE_BMP                        23       /* BMP  */
#define TITLE_FONT                       24       /* FONT */
#define TITLE_MUSIC                      25       /* MIDI */
#define TITLE_PAL                        26       /* PAL  */
#define TITLE_TEXT                       27       /* DATA */
#define WELCOME_SPL                      28       /* SAMP */

