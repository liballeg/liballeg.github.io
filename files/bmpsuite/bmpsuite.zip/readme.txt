BMP Suite - sample BMP image files
By Jason Summers <jason1@pobox.com>

Version: 2001.04.27

For more information: http://pobox.com/~jason1/bmpsuite/

Contents
--------

g01bw.bmp
g01wb.bmp
g01bg.bmp
g01p1.bmp
g04.bmp
g04p4.bmp
g08.bmp
g08offs.bmp
g08os2.bmp
g08w126.bmp
g08w125.bmp
g08w124.bmp
g08p256.bmp
g08pi256.bmp
g08pi64.bmp
g08res22.bmp
g08res21.bmp
g08res11.bmp
g08p64.bmp
g08s0.bmp
g16def555.bmp
g16bf555.bmp
g16bf565.bmp
g024.bmp
g32def.bmp
g32bf.bmp

-- end --
