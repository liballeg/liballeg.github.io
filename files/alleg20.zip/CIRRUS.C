/*         ______   ___    ___ 
 *        /\  _  \ /\_ \  /\_ \ 
 *        \ \ \L\ \\//\ \ \//\ \      __     __   _ __   ___ 
 *         \ \  __ \ \ \ \  \ \ \   /'__`\ /'_ `\/\`'__\/ __`\
 *          \ \ \/\ \ \_\ \_ \_\ \_/\  __//\ \L\ \ \ \//\ \L\ \
 *           \ \_\ \_\/\____\/\____\ \____\ \____ \ \_\\ \____/
 *            \/_/\/_/\/____/\/____/\/____/\/___L\ \/_/ \/___/
 *                                           /\____/
 *                                           \_/__/
 *      By Shawn Hargreaves,
 *      1 Salisbury Road,
 *      Market Drayton,
 *      Shropshire,
 *      England, TF9 1AJ.
 *
 *      Video driver for Cirrus 64xx and 54xx graphics cards.
 *
 *      See readme.txt for copyright information.
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pc.h>
#include <dpmi.h>
#include <go32.h>
#include <sys/movedata.h>
#include <sys/farptr.h>

#include "allegro.h"
#include "internal.h"


static BITMAP *cirrus_64_init(int w, int h, int v_w, int v_h);
static void cirrus_64_scroll(int x, int y);

static BITMAP *cirrus_54_init(int w, int h, int v_w, int v_h);
static void cirrus_54_scroll(int x, int y);



GFX_DRIVER gfx_cirrus64 = 
{
   "Cirrus 64xx",
   "",
   cirrus_64_init,
   NULL,
   cirrus_64_scroll,
   0, 0, FALSE, 
   0x10000,       /* 64k banks */
   0x1000,        /* 4k granularity */
   0
};



GFX_DRIVER gfx_cirrus54 = 
{
   "Cirrus 54xx",
   "",
   cirrus_54_init,
   NULL,
   cirrus_54_scroll,
   0, 0, FALSE, 
   0x10000,       /* 64k banks */
   0x1000,        /* 4k granularity */
   0
};



/* get_cirrus_64_mode:
 *  Returns a Cirrus 64xx mode number for the specified width and height.
 */
static int get_cirrus_64_mode(int w, int h)
{
   if ((w == 640) && (h == 400))
      return 0x2D;

   if ((w == 640) && (h == 480))
      return 0x2E;

   if ((w == 800) && (h == 600))
      return 0x30;

   return 0;
}



/* cirrus_64_detect:
 *  Detects the presence of a Cirrus 64xx card.
 */
static int cirrus_64_detect()
{
   int old;

   old = _read_vga_register(0x3CE, 0xA);

   _write_vga_register(0x3CE, 0xA, 0xCE);             /* disable extensions */
   if (_read_vga_register(0x3CE, 0xA) == 0) {
      _write_vga_register(0x3CE, 0xA, 0xEC);          /* enable extensions */
      if (_read_vga_register(0x3CE, 0xA) == 1)
	 return TRUE;
   }

   _write_vga_register(0x3CE, 0xA, old);
   return FALSE;
}



/* cirrus_64_init:
 *  Tries to enter the specified graphics mode, and makes a screen bitmap
 *  for it.
 */
static BITMAP *cirrus_64_init(int w, int h, int v_w, int v_h)
{
   BITMAP *b;
   int mode;
   int height;
   int width;
   __dpmi_regs r;

   if (!cirrus_64_detect()) {
      strcpy(allegro_error, "Cirrus 64xx not found");
      return NULL;
   }

   LOCK_FUNCTION(_cirrus64_read_bank);
   LOCK_FUNCTION(_cirrus64_write_bank);

   mode = get_cirrus_64_mode(w, h);
   if (mode == 0) {
      strcpy(allegro_error, "Resolution not supported");
      return NULL;
   }

   gfx_cirrus64.vid_mem = _vesa_vidmem_check(1024*1024);

   width = MAX(w, v_w);
   _sort_out_virtual_width(&width, &gfx_cirrus64);
   height = gfx_cirrus64.vid_mem / width;
   if ((width > 1024) || (h > height) || (v_w > width) || (v_h > height)) {
      strcpy(allegro_error, "Virtual screen size too large");
      return NULL;
   }

   b = _make_bitmap(width, height, 0xA0000, &gfx_cirrus64);
   if (!b)
      return NULL;

   r.x.ax = mode;
   __dpmi_int(0x10, &r);                        /* set gfx mode */

   _set_vga_virtual_width(w, width);

   _alter_vga_register(0x3CE, 0xD, 4, 4);       /* enable read/write banks */

   gfx_cirrus64.w = b->cr = w;
   gfx_cirrus64.h = b->cb = h;

   b->write_bank = _cirrus64_write_bank;
   b->read_bank = _cirrus64_read_bank;

   return b;
}



/* cirrus_64_scroll:
 *  Hardware scrolling for Cirrus 64xx cards.
 */
static void cirrus_64_scroll(int x, int y)
{
   long a = x + (y * VIRTUAL_W);

   /* write high bits to Cirrus 64xx registers */
   _write_vga_register(0x3CE, 0x7C, a>>18);

   /* write to normal VGA address registers */
   _write_vga_register(_crtc, 0x0D, (a>>2) & 0xFF);
   _write_vga_register(_crtc, 0x0C, (a>>10) & 0xFF);
}



/* get_cirrus_54_mode:
 *  Returns a Cirrus 54xx mode number for the specified width and height.
 */
static int get_cirrus_54_mode(int w, int h)
{
   if ((w == 640) && (h == 480))
      return 0x5F;

   if ((w == 800) && (h == 600))
      return 0x5C;

   if ((w == 1024) && (h == 768))
      return 0x60;

   return 0;
}



/* cirrus_54_detect:
 *  Detects the presence of a Cirrus 54xx card.
 */
static int cirrus_54_detect()
{
   int old;

   old = _read_vga_register(0x3C4, 6);

   _write_vga_register(0x3C4, 6, 0);                  /* disable extensions */
   if (_read_vga_register(0x3C4, 6) == 0xF) {
      _write_vga_register(0x3C4, 6, 0x12);            /* enable extensions */
      if ((_read_vga_register(0x3C4, 6) == 0x12) &&
	  (_test_vga_register(0x3C4, 0x1E, 0x3F)))
	 return TRUE;
   }

   _write_vga_register(0x3C4, 6, old);
   return FALSE;
}



/* cirrus_54_init:
 *  Tries to enter the specified graphics mode, and makes a screen bitmap
 *  for it.
 */
static BITMAP *cirrus_54_init(int w, int h, int v_w, int v_h)
{
   BITMAP *b;
   int mode;
   int height;
   int width;
   __dpmi_regs r;

   if (!cirrus_54_detect()) {
      strcpy(allegro_error, "Cirrus 54xx not found");
      return NULL;
   }

   LOCK_FUNCTION(_cirrus54_bank);

   mode = get_cirrus_54_mode(w, h);
   if (mode == 0) {
      strcpy(allegro_error, "Resolution not supported");
      return NULL;
   }

   gfx_cirrus54.vid_mem = _vesa_vidmem_check(1024*1024);

   width = MAX(w, v_w);
   _sort_out_virtual_width(&width, &gfx_cirrus54);
   height = gfx_cirrus54.vid_mem / width;
   if ((width > 1024) || (h > height) || (v_w > width) || (v_h > height)) {
      strcpy(allegro_error, "Virtual screen size too large");
      return NULL;
   }

   b = _make_bitmap(width, height, 0xA0000, &gfx_cirrus54);
   if (!b)
      return NULL;

   r.x.ax = mode;
   __dpmi_int(0x10, &r);                        /* set gfx mode */

   _set_vga_virtual_width(w, width);

   _alter_vga_register(0x3CE, 0xB, 33, 0);      /* 4k banks, single page */

   gfx_cirrus54.w = b->cr = w;
   gfx_cirrus54.h = b->cb = h;

   b->write_bank = b->read_bank = _cirrus54_bank;

   return b;
}



/* cirrus_54_scroll:
 *  Hardware scrolling for Cirrus 54xx cards.
 */
static void cirrus_54_scroll(int x, int y)
{
   long a = x + (y * VIRTUAL_W);
   long t;

   /* write high bits to Cirrus 54xx registers */
   t = a >> 18;
   t += (t&6);    /* funny format, uses bits 0, 2, and 3 */
   _alter_vga_register(_crtc, 0x1B, 0xD, t);

   /* write to normal VGA address registers */
   _write_vga_register(_crtc, 0x0D, (a>>2) & 0xFF);
   _write_vga_register(_crtc, 0x0C, (a>>10) & 0xFF);

   /* write low 2 bits to VGA horizontal pan register */
   vsync();
   _alter_vga_register(0x3C0, 0x33, 0x0F, a&3);
}

