#ifndef ANIMSEL_H_INCLUDED
#define ANIMSEL_H_INCLUDED

#include "demo.h"
int pick_animation_type(int *type);

#endif
