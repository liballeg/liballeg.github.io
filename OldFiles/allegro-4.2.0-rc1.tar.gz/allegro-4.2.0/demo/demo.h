#ifndef DEMO_H_INCLUDED
#define DEMO_H_INCLUDED

#include <allegro.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

extern DATAFILE *data;
extern int max_fps;
extern int cheat;

#endif
