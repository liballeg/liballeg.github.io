#ifndef MAKEDEVHELP_H
#define MAKEDEVHELP_H

int write_devhelp(const char *filename);

#endif
