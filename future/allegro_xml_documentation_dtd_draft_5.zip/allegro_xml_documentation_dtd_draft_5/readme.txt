Draft 5 attached (based on latest Laurence's suggestions). It should be
complete now and ready for testing and bugfixing.

Changes since draft 4

- struct and union have members instead of arguments
- block-level elements are now the same as para element
- avoid recursion in some inline elements

To-do list (everyone is welcome to do these)

- put DTD into CVS (new module allegdoc)
- test DTD by writing some small docfile
- test DTD by converting docfile to HTML using some simple XSLT
- write scripts which will ease conversion of actual documentation to the
new format
- rewrite makedoc to support new format

Have a nice sleep. I hope I will.

Stepan Roh
